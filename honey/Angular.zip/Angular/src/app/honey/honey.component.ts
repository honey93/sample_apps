import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-honey',
  templateUrl: './honey.component.html',
  styleUrls: ['./honey.component.css']
})
export class HoneyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
