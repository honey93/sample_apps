import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-him-anshi',
  templateUrl: './him-anshi.component.html',
  styleUrls: ['./him-anshi.component.css']
})
export class HimAnshiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
