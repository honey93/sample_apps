import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HimAnshiComponent } from './him-anshi.component';

describe('HimAnshiComponent', () => {
  let component: HimAnshiComponent;
  let fixture: ComponentFixture<HimAnshiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HimAnshiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HimAnshiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
