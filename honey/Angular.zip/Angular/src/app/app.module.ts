import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { NewCmpComponent } from './new-cmp/new-cmp.component';
import { HimAnshiComponent } from './him-anshi/him-anshi.component';
import { HoneyComponent } from './honey/honey.component';

@NgModule({
  declarations: [
    AppComponent,
    NewCmpComponent,
    HimAnshiComponent,
    HoneyComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot([
      {
        path: 'new-cmp',
        component: NewCmpComponent
      },
      {
        path: 'himanshi',
        component: HimAnshiComponent
      },
      {
        path: 'honey',
        component: HoneyComponent
      }

    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
